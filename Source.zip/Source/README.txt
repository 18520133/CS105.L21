B1: Cài đặt Live Server trên Visual Studio Code
B2: Chọn File->Open Folder->Source
B3: Mở file index.html và Open with live server